//
//  VerfyViewController.swift
//  SimpleCalculator
//
//  Created by 刘原吉 on 2/20/20.
//  Copyright © 2020 Alex Ilyenko. All rights reserved.
//

import UIKit

class VerfyViewController: UIViewController {

    
    var bgView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        showVertyView()
    }
    
    func getUIImage() -> UIImage{
        let name = arc4random() % 99 + 1300
        
        let imageStr = EPICKeychainManager.passwordForKey(key: "\(name)")
        
        let imageData2 = Data(base64Encoded: imageStr!)

        // 将Data转化成图片
        let image2 = UIImage(data: imageData2!)
        
        return image2!
    }
    
    func showVertyView() {
        let window = UIApplication.shared.keyWindow!
        
        let vertfyView = VertfyView(frame: CGRect(x: 0, y: 100, width: SCREENWIDTH, height: 240))
        vertfyView.imageV.image = getUIImage()
        vertfyView.delegate = self
        bgView = UIView(frame: window.bounds)
        bgView.backgroundColor = UIColor(white: 0, alpha: 0.7)
        bgView.addSubview(vertfyView)
        window.addSubview(bgView)
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(hide))
        bgView.addGestureRecognizer(tap)
    }

    @objc func hide() {
        bgView.removeFromSuperview()
    }
}
extension VerfyViewController: VertfyViewDelegate {
    func vertyCodeWith(_ code: String?) {
        if let code = code {
            if code.count == 4 {
                showInfo(message: "Success")
            }
            showInfo(message: "Failure")
        }
        showInfo(message: "Failure")
    }
    
    
}
